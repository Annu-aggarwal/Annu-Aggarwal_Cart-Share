/**
 * CartShare — app.js
 * Collaborative shopping cart with cross-tab sync via localStorage + storage events
 */

// ─── Constants ───────────────────────────────────────────────────────────────
const FREE_DELIVERY_THRESHOLD = 750; // ₹750

// ─── State ───────────────────────────────────────────────────────────────────
let state = {
  roomCode: null,
  userName: null,
  userId: null,       // unique per tab session
};

// ─── Helpers ─────────────────────────────────────────────────────────────────
function genCode(len = 6) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}

function genId() {
  return Math.random().toString(36).slice(2, 10);
}

function now() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function storageKey(type) {
  return `cartshare_${state.roomCode}_${type}`;
}

// ─── localStorage helpers ─────────────────────────────────────────────────────
function getCart() {
  try { return JSON.parse(localStorage.getItem(storageKey('cart'))) || []; }
  catch { return []; }
}
function saveCart(cart) {
  localStorage.setItem(storageKey('cart'), JSON.stringify(cart));
}

function getLog() {
  try { return JSON.parse(localStorage.getItem(storageKey('log'))) || []; }
  catch { return []; }
}
function saveLog(log) {
  localStorage.setItem(storageKey('log'), JSON.stringify(log.slice(-50))); // keep last 50 entries
}

function getParticipants() {
  try { return JSON.parse(localStorage.getItem(storageKey('participants'))) || []; }
  catch { return []; }
}
function saveParticipants(p) {
  localStorage.setItem(storageKey('participants'), JSON.stringify(p));
}

// ─── Room logic ───────────────────────────────────────────────────────────────
function enterRoom(roomCode, userName) {
  state.roomCode = roomCode;
  state.userName = userName;
  state.userId = genId();

  // Register participant
  const participants = getParticipants();
  if (!participants.find(p => p.name === userName)) {
    participants.push({ id: state.userId, name: userName });
    saveParticipants(participants);
  }

  // Log entry
  addLog(`<strong>${userName}</strong> joined the room`);
}

function leaveRoom() {
  // Remove this user from participants
  let participants = getParticipants();
  participants = participants.filter(p => p.id !== state.userId);
  saveParticipants(participants);

  addLog(`<strong>${state.userName}</strong> left the room`);

  state.roomCode = null;
  state.userName = null;
  state.userId = null;

  showJoinScreen();
}

// ─── Activity Log ─────────────────────────────────────────────────────────────
function addLog(message) {
  const log = getLog();
  log.push({ message, time: now() });
  saveLog(log);
  renderLog();
}

function renderLog() {
  const log = getLog();
  const el = document.getElementById('activity-log');
  if (!log.length) {
    el.innerHTML = '<li style="opacity:0.5">No activity yet...</li>';
    return;
  }
  el.innerHTML = log.map(entry =>
    `<li><span class="log-time">${entry.time}</span>${entry.message}</li>`
  ).join('');
}

// ─── Cart logic ───────────────────────────────────────────────────────────────
function addItem(name, qty, price) {
  const cart = getCart();
  cart.push({
    id: genId(),
    name,
    qty: parseInt(qty),
    price: parseFloat(price),
    addedBy: state.userName,
    addedAt: now(),
  });
  saveCart(cart);
  addLog(`<strong>${state.userName}</strong> added <strong>${qty}× ${name}</strong> (₹${price})`);
  renderCart();
}

function removeItem(itemId) {
  let cart = getCart();
  const item = cart.find(i => i.id === itemId);
  if (!item) return;
  cart = cart.filter(i => i.id !== itemId);
  saveCart(cart);
  addLog(`<strong>${state.userName}</strong> removed <strong>${item.name}</strong>`);
  renderCart();
}

function renderCart() {
  const cart = getCart();
  const listEl = document.getElementById('cart-list');
  const emptyEl = document.getElementById('empty-cart');
  const totalEl = document.getElementById('cart-total');

  if (!cart.length) {
    listEl.innerHTML = '';
    listEl.appendChild(emptyEl);
    emptyEl.style.display = 'block';
    totalEl.textContent = '₹0.00';
    updateThreshold(0);
    return;
  }

  emptyEl.style.display = 'none';

  let total = 0;
  listEl.innerHTML = cart.map(item => {
    const subtotal = item.qty * item.price;
    total += subtotal;
    return `
      <div class="cart-item" data-id="${item.id}">
        <div class="cart-item-name">
          ${escHtml(item.name)}
          <span class="cart-item-meta">by ${escHtml(item.addedBy)} · ${item.addedAt}</span>
        </div>
        <span class="cart-item-qty">×${item.qty}</span>
        <span class="cart-item-price">₹${subtotal.toFixed(2)}</span>
        <button class="btn-remove" data-id="${item.id}" title="Remove">✕</button>
      </div>`;
  }).join('');

  // Attach remove listeners
  listEl.querySelectorAll('.btn-remove').forEach(btn => {
    btn.addEventListener('click', () => removeItem(btn.dataset.id));
  });

  totalEl.textContent = `₹${total.toFixed(2)}`;
  updateThreshold(total);
}

function updateThreshold(total) {
  const fill = document.getElementById('threshold-fill');
  const label = document.getElementById('threshold-label');
  const badge = document.getElementById('threshold-badge');
  const pct = Math.min((total / FREE_DELIVERY_THRESHOLD) * 100, 100);
  fill.style.width = pct + '%';

  if (total >= FREE_DELIVERY_THRESHOLD) {
    label.textContent = `✓ Free delivery unlocked!`;
    badge.textContent = 'Free delivery ✓';
    badge.className = 'threshold-badge met';
  } else {
    const remaining = (FREE_DELIVERY_THRESHOLD - total).toFixed(2);
    label.textContent = `₹${remaining} more for free delivery`;
    badge.textContent = `₹${remaining} away`;
    badge.className = 'threshold-badge unmet';
  }
}

// ─── Participants ─────────────────────────────────────────────────────────────
function renderParticipants() {
  const participants = getParticipants();
  const el = document.getElementById('participants-list');
  if (!participants.length) {
    el.innerHTML = '<span style="font-size:0.85rem;color:#999">No one here yet.</span>';
    return;
  }
  el.innerHTML = participants.map(p => {
    const isYou = p.id === state.userId || p.name === state.userName;
    return `<div class="participant-chip ${isYou ? 'you' : ''}">
      <span class="dot"></span>
      ${escHtml(p.name)}${isYou ? ' (you)' : ''}
    </div>`;
  }).join('');
}

// ─── Receipt ─────────────────────────────────────────────────────────────────
function showReceipt() {
  const cart = getCart();
  const participants = getParticipants();
  const receiptEl = document.getElementById('receipt-view');

  document.getElementById('r-room-code').textContent = state.roomCode;
  document.getElementById('r-date').textContent = new Date().toLocaleString();
  document.getElementById('r-participants').textContent =
    'Participants: ' + participants.map(p => p.name).join(', ');

  let total = 0;
  document.getElementById('r-items').innerHTML = cart.map(item => {
    const sub = item.qty * item.price;
    total += sub;
    return `<tr>
      <td>${escHtml(item.name)}</td>
      <td>${escHtml(item.addedBy)}</td>
      <td>${item.qty}</td>
      <td>₹${parseFloat(item.price).toFixed(2)}</td>
      <td>₹${sub.toFixed(2)}</td>
    </tr>`;
  }).join('');

  document.getElementById('r-total').textContent = `₹${total.toFixed(2)}`;

  receiptEl.classList.remove('d-none');

  // Add a close button if not already there
  if (!document.getElementById('close-receipt-btn')) {
    const btn = document.createElement('button');
    btn.id = 'close-receipt-btn';
    btn.className = 'btn cs-btn-secondary';
    btn.textContent = '← Back to Cart';
    btn.onclick = () => {
      receiptEl.classList.add('d-none');
    };
    receiptEl.querySelector('.receipt-paper').appendChild(btn);
  }

  setTimeout(() => window.print(), 200);
}

// ─── Screen switching ─────────────────────────────────────────────────────────
function showJoinScreen() {
  document.getElementById('join-screen').classList.add('active');
  document.getElementById('app-screen').classList.remove('active');
}

function showAppScreen() {
  document.getElementById('join-screen').classList.remove('active');
  document.getElementById('app-screen').classList.add('active');

  document.getElementById('header-room-code').textContent = state.roomCode;
  document.getElementById('header-user').textContent = state.userName;

  renderCart();
  renderLog();
  renderParticipants();
}

// ─── Cross-tab sync via storage events ───────────────────────────────────────
window.addEventListener('storage', (e) => {
  if (!state.roomCode) return;
  if (e.key && e.key.startsWith(`cartshare_${state.roomCode}_`)) {
    renderCart();
    renderLog();
    renderParticipants();
  }
});

// ─── Sanitize HTML ───────────────────────────────────────────────────────────
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ─── DOM Event Listeners ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

  // — Create Room —
  document.getElementById('create-room-btn').addEventListener('click', () => {
    const name = document.getElementById('user-name').value.trim();
    if (!name) { showError('join-error', 'Please enter your name first.'); return; }
    const code = genCode();
    enterRoom(code, name);
    showAppScreen();
  });

  // — Join Room —
  document.getElementById('join-room-btn').addEventListener('click', () => {
    const name = document.getElementById('user-name').value.trim();
    const code = document.getElementById('room-code-input').value.trim().toUpperCase();
    if (!name) { showError('join-error', 'Please enter your name.'); return; }
    if (code.length < 4) { showError('join-error', 'Enter a valid room code.'); return; }
    // For simulation: any code is accepted (no server required)
    enterRoom(code, name);
    showAppScreen();
  });

  // — Enter key on room code input —
  document.getElementById('room-code-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('join-room-btn').click();
  });

  // — Leave Room —
  document.getElementById('leave-btn').addEventListener('click', () => {
    if (confirm('Leave the room?')) leaveRoom();
  });

  // — Add Item —
  document.getElementById('add-item-btn').addEventListener('click', () => {
    const name  = document.getElementById('item-name').value.trim();
    const qty   = document.getElementById('item-qty').value;
    const price = document.getElementById('item-price').value;
    const errEl = document.getElementById('add-error');

    if (!name) { showError('add-error', 'Item name is required.'); return; }
    if (!qty || parseInt(qty) < 1) { showError('add-error', 'Quantity must be at least 1.'); return; }
    if (!price || parseFloat(price) < 0) { showError('add-error', 'Enter a valid price.'); return; }

    errEl.classList.add('d-none');
    addItem(name, qty, price);

    // Reset form
    document.getElementById('item-name').value = '';
    document.getElementById('item-qty').value = 1;
    document.getElementById('item-price').value = '';
    document.getElementById('item-name').focus();
  });

  // — Add on Enter key in item name —
  document.getElementById('item-name').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('add-item-btn').click();
  });

  // — Print Receipt —
  document.getElementById('print-receipt-btn').addEventListener('click', showReceipt);

});

function showError(elId, msg) {
  const el = document.getElementById(elId);
  el.textContent = msg;
  el.classList.remove('d-none');
  setTimeout(() => el.classList.add('d-none'), 3000);
}
