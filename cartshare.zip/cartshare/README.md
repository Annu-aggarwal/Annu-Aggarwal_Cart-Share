# 🛒 CartShare

A collaborative, real-time shared shopping cart web app built for the Internship Studio project.

---

## 🚀 Live Demo

> Deploy on [Vercel](https://vercel.com), [Netlify](https://netlify.com), or [GitHub Pages](https://pages.github.com) and paste the URL here.

---

## ✨ Features

- **Create or Join a Room** using a unique room code
- **Shared Cart** — add/remove items that sync across browser tabs in real time
- **Activity Log** — live feed of who added or removed what
- **Free Delivery Tracker** — visual progress bar toward the ₹750 free delivery threshold
- **Participants Panel** — shows everyone currently in the room
- **Printable Receipt** — generates a clean, audit-ready summary using CSS print rules
- **Fully Responsive** — works on mobile and desktop

---

## 🗂️ Folder Structure

```
CartShare/
├── index.html          # Main app entry point
├── css/
│   └── style.css       # All styles (responsive, print media)
├── js/
│   └── app.js          # App logic, localStorage sync, cross-tab events
├── assets/             # (Place images or icons here if needed)
└── README.md
```

---

## 🛠️ How to Run Locally

1. **Clone the repo:**
   ```bash
   git clone https://github.com/YOUR_USERNAME/CartShare.git
   cd CartShare
   ```

2. **Open in browser:**
   Simply open `index.html` in any modern browser — no build step required.
   
   Or use a local server (recommended for cross-tab sync testing):
   ```bash
   npx serve .
   # then open http://localhost:3000
   ```

3. **Simulate multiple users:**
   - Open the app in two or more browser tabs
   - Create a room in one tab, copy the room code
   - Paste and join the same code in another tab
   - Add/remove items and watch both tabs update in real time!

---

## 📦 Tech Stack

| Feature | Implementation |
|---|---|
| UI Framework | Bootstrap 5.3 |
| Fonts | Space Grotesk + Inter (Google Fonts) |
| Data Persistence | `localStorage` |
| Real-time Sync | `window.storage` event (cross-tab) |
| Printing | CSS `@media print` + `window.print()` |
| Routing | Pure JS screen switching (no framework) |

---

## 📤 Submission

**Format:** `BatchID_FullName_CartShare`

- GitHub Repo: `https://github.com/YOUR_USERNAME/CartShare`
- Live URL: `https://YOUR_DEPLOYMENT_URL`

---

## 👤 Author

**Your Name** — Internship Studio, 2025
